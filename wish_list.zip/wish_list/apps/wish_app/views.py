from django.shortcuts import render, redirect, reverse
from django.contrib import messages
from ..login_app.models import User
from .models import Wish

def flashErrors(request, errors):
    for error in errors:
        messages.error(request, error)

def index(request):
    if 'user_id' in request.session:
        user = User.objects.currentUser(request)
        wishlist = user.items.all()
        other_wishes = Wish.objects.exclude(id__in = wishlist)

        context = {
            'user': user,
            'wishlist': wishlist,
            'other_wishes': other_wishes,
        }
        
        return render(request, 'wish_app/index.html', context)
    return redirect(reverse('landing'))
    
# def new_wishPage(request):
#     if 'user_id' not in request.session:
#         return redirect(reverse('success'))
#         # return render(request, 'wish_app/index.html')

def create(request):
    user = User.objects.currentUser(request)
    if request.method == "POST":
        errors = []
        if len(request.POST['content']) != 0:
            errors.append('Please enter your Wish!')
            flashErrors(request, errors)
            #so if content is not empty then lets create a wish method
            wish = Wish.objects.createWish(request.POST, user)
        else:
            user = User.objects.currentUser(request)
            wish = Wish.objects.create(
                content = request.POST['content'],
                creator = user
            )
            wish.users.add(user)
            return redirect(reverse('create'))
    return redirect(reverse('success'))

#so now we just need to relate the two tables = .add method..
#to get to the relationship from the Secret it would be = Secret.liked_by
#to get to the rel from the User it would be = User.likes
#one way: current_user.likes.add(secret) & another way secret.liked_by.add(current_user)

def deleteWish(request, id):
    user = User.objects.currentUser(request)
    wish = Wish.objects.get(id = id)
    wish.delete()
    return redirect(reverse('success'))

def addWish(request, id):
    user = User.objects.currentUser(request)
    wish = Wish.objects.get(id = id)
    wish.users.add(user)
    return redirect(reverse('success'))

def removeWish(request, id):
    user = User.objects.currentUser(request)
    wish = Wish.objects.get(id = id)
    wish.users.remove(user)
    return redirect(reverse('success'))

def new_wishPage(request, id):
    print "*"*100
    print "success"
    if 'user_id' not in request.session:
        return redirect('success')
    wish = Wish.objects.get(id = id)
    users = wish.users.all()
    context = {
        'users': users
    }
    return redirect(reverse('create'))
