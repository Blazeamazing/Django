from __future__ import unicode_literals
from django.db import models
from ..login_app.models import User
import bcrypt

# Create your models here.
class WishManager(models.Manager):
    def validate(self, form_data):
        pass

    def createWish(self, form_data, user):
        wish = Wish.objects.create(
            name = form_data['content'],
            creator = user
        )

        return wish

class Wish(models.Model):
    content = models.CharField(max_length = 255)
    creator = models.ForeignKey(User, related_name = "other_items")
    users = models.ManyToManyField(User, related_name = "items")
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)

    objects = WishManager()