from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^create$', views.create, name='create'),
    url(r'^new_wish/create$', views.new_wishPage, name='new_wish/create'),
    url(r'^deleteWish(?P<id>\d+)$', views.deleteWish, name='deleteWish'),
    url(r'^addWish(?P<id>\d+)$', views.addWish, name='addWish'),
    url(r'^removeWish(?P<id>\d+)$', views.removeWish, name='removeWish'),
    url(r'^$', views.index, name='success'),
]
